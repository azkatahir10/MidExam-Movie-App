import React from "react";
import '../scss/MovieList.scss'

function MovieList() { 
return (
    <Footer expand="lg-lg" bg="dark" variant="light">
        <div className="socialMedia">
            <ul>
                <li></li>
                <li>Azka Tahir is gonna do it, Insh-a-Alah.</li>
                <li>Hello</li>
            </ul>
        </div> 
    </Footer>
)};

export default MovieList();