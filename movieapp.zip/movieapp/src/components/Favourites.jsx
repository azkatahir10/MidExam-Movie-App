import React, { useContext } from 'react';
import MovieList from '../components/MovieList';
import { FavoritesContext } from '../context/FavoritesContext';
import './Favorites.scss';

const Favorites = () => {
  const { favoriteMovies } = useContext(FavoritesContext);

  return (
    <div className="favorites-page">
      <h1>Your Favorite Movies</h1>
      {favoriteMovies.length > 0 ? (
        <MovieList movies={favoriteMovies} />
      ) : (
        <p>No favorite movies added yet.</p>
      )}
    </div>
  );
};

export default Favorites;
