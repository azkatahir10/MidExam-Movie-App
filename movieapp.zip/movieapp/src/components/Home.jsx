import React, { useState, useEffect } from 'react';
import axios from 'axios';
import MovieList from '../components/MovieList';
import './Home.scss';

const Home = () => {
  const [movies, setMovies] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTrendingMovies = async () => {
      try {
        const response = await axios.get(`https://api.themoviedb.org/3/trending/movie/week?api_key=YOUR_API_KEY`);
        setMovies(response.data.results);
      } catch (error) {
        console.error("Error fetching trending movies", error);
      }
      setLoading(false);
    };

    fetchTrendingMovies();
  }, []);

  return (
    <div className="home">
      <h1>Trending Movies</h1>
      {loading ? <p>Loading...</p> : <MovieList movies={movies} />}
    </div>
  );
};

export default Home;
