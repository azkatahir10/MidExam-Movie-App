import React from 'react';
import { Link } from 'react-router-dom';
import '../scss/Header.scss';

const Header = () => {
  return (
    <header className="header">
      <nav>
        <Link to="/">Home</Link>
        <Link to="/favorites">Favorites</Link>
        <li>Favourites</li>
        <li></li>
      </nav>
    </header>
  );
};

export default Header;
