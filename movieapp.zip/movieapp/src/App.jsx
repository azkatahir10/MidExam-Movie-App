import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Home from './components/Header'
import Movies from './components/Movies';
import Favorites from './components/Favourites';
import Header from './components/Header';
import Footer from './components/Footer';
import { FavoritesProvider } from './context/FavoritesContext';
import './App.css';

const App = () => {
  return (
    <FavoritesProvider>
      <Router>
        <div className="app">
          <Header />
          <main className="content">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/movies" element={<Movies />} />
              <Route path="/favorites" element={<Favorites />} />
            </Routes>
          </main>
          <Footer />
        </div>
      </Router>
    </FavoritesProvider>
  );
};

export default App;
